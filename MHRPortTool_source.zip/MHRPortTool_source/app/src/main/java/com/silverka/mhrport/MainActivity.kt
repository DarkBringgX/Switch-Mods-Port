package com.silverka.mhrport

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import com.silverka.mhrport.core.FolderSource
import com.silverka.mhrport.core.ModSource
import com.silverka.mhrport.core.PakBuilder
import com.silverka.mhrport.core.Porter
import com.silverka.mhrport.core.ZipSource
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private companion object {
        const val REQ_ZIP = 1
        const val REQ_FOLDER = 2
        const val REQ_OUT = 3
        const val PREFS = "mhrport"
    }

    private var sourceUri: Uri? = null
    private var sourceIsZip = true
    private var outUri: Uri? = null

    private lateinit var tvSource: TextView
    private lateinit var tvOut: TextView
    private lateinit var etPatch: EditText
    private lateinit var btnGo: Button
    private lateinit var progress: ProgressBar
    private lateinit var tvLog: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(16), px(16), px(16))
        }
        fun label(text: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
            setShadowLayer(6f, 0f, 0f, android.graphics.Color.BLACK)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        fun button(text: String, onClick: () -> Unit) = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(label("MHR PC → Switch Port", 22f, true))
        root.addView(label("Ubah mod Monster Hunter Rise PC jadi PAK patch untuk Switch.\nBy DarkX (base from SILVER KA edited Files)", 13f))

        root.addView(label("\n1. Mod (hasil download Nexus)", 15f, true))
        root.addView(button("Pilih file ZIP mod") { pickZip() })
        root.addView(button("…atau pilih folder yang berisi 'natives'") { pickFolder(REQ_FOLDER) })
        tvSource = label("Belum dipilih")
        root.addView(tvSource)

        root.addView(label("\n2. Folder hasil", 15f, true))
        root.addView(button("Pilih folder output") { pickFolder(REQ_OUT) })
        tvOut = label("Belum dipilih")
        root.addView(tvOut)

        root.addView(label("\n3. Nomor patch (mulai 016 dst)", 15f, true))
        etPatch = EditText(this).apply {
            setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("patch", "016"))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setTextColor(android.graphics.Color.WHITE)
        }
        root.addView(etPatch)

        btnGo = button("Konversi & buat PAK") { start() }
        root.addView(btnGo)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = android.view.View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        tvLog = TextView(this).apply {
            textSize = 12f
            typeface = android.graphics.Typeface.MONOSPACE
            gravity = Gravity.START
            setTextColor(android.graphics.Color.WHITE)
            setShadowLayer(6f, 0f, 0f, android.graphics.Color.BLACK)
        }
        root.addView(tvLog)

        scroll = ScrollView(this).apply { addView(root) }

        // Background image (res/drawable/bg.jpg) + dark overlay so text stays readable
        val frame = android.widget.FrameLayout(this)
        val mp = ViewGroup.LayoutParams.MATCH_PARENT
        frame.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.bg)
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
        }, ViewGroup.LayoutParams(mp, mp))
        frame.addView(android.view.View(this).apply {
            setBackgroundColor(0x66000000)
        }, ViewGroup.LayoutParams(mp, mp))
        frame.addView(scroll, ViewGroup.LayoutParams(mp, mp))
        setContentView(frame)

        val sp = getSharedPreferences(PREFS, MODE_PRIVATE)
        sp.getString("out", null)?.let {
            val u = Uri.parse(it)
            if (hasPersisted(u)) { outUri = u; tvOut.text = describe(u) }
        }
    }

    private fun hasPersisted(u: Uri) = contentResolver.persistedUriPermissions.any { it.uri == u }

    private fun describe(u: Uri): String = u.lastPathSegment ?: u.toString()

    private fun pickZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        startActivityForResult(i, REQ_ZIP)
    }

    private fun pickFolder(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_ZIP -> {
                sourceUri = uri; sourceIsZip = true
                tvSource.text = "ZIP: " + describe(uri)
            }
            REQ_FOLDER -> {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                sourceUri = uri; sourceIsZip = false
                tvSource.text = "Folder: " + describe(uri)
            }
            REQ_OUT -> {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                outUri = uri
                tvOut.text = describe(uri)
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("out", uri.toString()).apply()
            }
        }
    }

    private fun log(msg: String) {
        runOnUiThread {
            tvLog.append(msg + "\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun start() {
        val src = sourceUri
        val out = outUri
        if (src == null) { log("Pilih mod (ZIP atau folder) dulu."); return }
        if (out == null) { log("Pilih folder output dulu."); return }
        val num = etPatch.text.toString().trim().ifEmpty { "016" }.padStart(3, '0')
        val pakName = "re_chunk_000.pak.patch_$num.pak"

        btnGo.isEnabled = false
        progress.visibility = android.view.View.VISIBLE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tvLog.text = ""

        thread {
            val work = File(cacheDir, "work")
            try {
                log("[1/3] Membaca mod & mengonversi tekstur…")
                val source: ModSource =
                    if (sourceIsZip) ZipSource(contentResolver, src)
                    else FolderSource(contentResolver, DocumentFile.fromTreeUri(this, src)
                        ?: throw IllegalStateException("Folder mod tidak bisa dibuka"))
                val porter = Porter(work) { log(it) }
                porter.run(source)
                log("    tekstur dikonversi: ${porter.converted}, file lain: ${porter.copied}, disalin apa adanya: ${porter.skipped}")

                log("[2/3] Membungkus ${porter.result.size} file → $pakName")
                val dir = DocumentFile.fromTreeUri(this, out)
                    ?: throw IllegalStateException("Folder output tidak bisa dibuka")
                dir.findFile(pakName)?.delete()
                val target = dir.createFile("application/octet-stream", pakName)
                    ?: throw IllegalStateException("Gagal membuat file output")
                if (target.name != pakName) target.renameTo(pakName)
                contentResolver.openOutputStream(target.uri, "w")!!.buffered().use { os ->
                    PakBuilder.write(porter.result, os)
                }

                log("[3/3] Bersih-bersih…")
                work.deleteRecursively()
                val next = (num.toInt() + 1).toString().padStart(3, '0')
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("patch", next).apply()
                runOnUiThread { etPatch.setText(next) }
                log("\nSELESAI! File: $pakName\nSalin ke folder game (sebelah re_chunk_000.pak). Nomor patch berikutnya: $next")
            } catch (t: Throwable) {
                log("\nERROR: ${t.javaClass.simpleName}: ${t.message}")
                work.deleteRecursively()
            } finally {
                runOnUiThread {
                    btnGo.isEnabled = true
                    progress.visibility = android.view.View.GONE
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }
    }
}
