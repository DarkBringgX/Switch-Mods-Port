package com.silverka.mhrport.core

import android.content.ContentResolver
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.util.zip.ZipInputStream

class ZipSource(private val resolver: ContentResolver, private val uri: Uri) : ModSource {
    override fun walk(sink: FileSink) {
        val raw = resolver.openInputStream(uri) ?: throw IllegalStateException("Tidak bisa membuka ZIP")
        ZipInputStream(raw.buffered()).use { zip ->
            // jangan tutup stream per-entri: sink hanya membaca dari zip
            val guard = object : java.io.FilterInputStream(zip) {
                override fun close() { /* ditahan */ }
            }
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                sink.accept(e.name, guard)
            }
        }
    }
}

class FolderSource(private val resolver: ContentResolver, private val root: DocumentFile) : ModSource {
    override fun walk(sink: FileSink) {
        visit(root, "", sink)
    }

    private fun visit(dir: DocumentFile, prefix: String, sink: FileSink) {
        for (f in dir.listFiles()) {
            val name = f.name ?: continue
            if (f.isDirectory) {
                visit(f, "$prefix$name/", sink)
            } else if (f.isFile) {
                resolver.openInputStream(f.uri)?.use { sink.accept("$prefix$name", it) }
            }
        }
    }
}
