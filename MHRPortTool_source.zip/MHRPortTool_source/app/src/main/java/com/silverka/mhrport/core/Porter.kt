package com.silverka.mhrport.core

import java.io.File
import java.io.InputStream

/** Sumber file mod: ZIP atau folder. Memanggil [FileSink] untuk tiap file. */
fun interface FileSink {
    fun accept(relPath: String, input: InputStream)
}

interface ModSource {
    fun walk(sink: FileSink)
}

/**
 * Alur sama dengan auto_port.bat:
 *  1. ambil folder natives dari mod
 *  2. natives/STM -> natives/NSW
 *  3. semua *.tex.28 dikonversi PC -> Switch
 *  4. bungkus menjadi PAK patch
 */
class Porter(private val workDir: File, private val log: (String) -> Unit) {
    private val entries = LinkedHashMap<String, PakEntry>()
    var converted = 0
        private set
    var copied = 0
        private set
    var skipped = 0
        private set

    val result: List<PakEntry> get() = entries.values.sortedBy { it.path.lowercase() }

    fun run(source: ModSource) {
        workDir.deleteRecursively()
        workDir.mkdirs()
        source.walk { rel, input -> handle(rel, input) }
        if (entries.isEmpty()) {
            throw IllegalStateException("Folder 'natives' tidak ditemukan di mod ini!")
        }
    }

    private fun mapPath(rel: String): String? {
        val parts = rel.replace('\\', '/').split('/').filter { it.isNotEmpty() }
        if (parts.contains("__MACOSX")) return null
        val idx = parts.indexOfFirst { it.equals("natives", ignoreCase = true) }
        if (idx < 0 || idx == parts.size - 1) return null
        val tail = parts.subList(idx + 1, parts.size).toMutableList()
        if (tail.size >= 2 && tail[0].equals("STM", ignoreCase = true)) tail[0] = "NSW"
        return "natives/" + tail.joinToString("/")
    }

    private fun handle(rel: String, input: InputStream) {
        val path = mapPath(rel) ?: return
        val name = path.substringAfterLast('/')
        if (name == ".DS_Store" || name.equals("Thumbs.db", ignoreCase = true)) return

        val tmp = File(workDir, "f" + entries.size + "_" + System.nanoTime() + ".bin")
        if (path.endsWith(".tex.28", ignoreCase = true)) {
            val data = input.readBytes()
            try {
                if (path.contains("/streaming/", ignoreCase = true))
                    throw TexSkip("tekstur streaming tidak diproses")
                tmp.writeBytes(TexConverter.convert(data))
                converted++
                log("✔ tex  $path")
            } catch (e: TexSkip) {
                tmp.writeBytes(data)
                skipped++
                log("• salin $path (${e.message})")
            } catch (e: Exception) {
                tmp.writeBytes(data)
                skipped++
                log("! gagal $path: ${e.javaClass.simpleName} ${e.message} — disalin apa adanya")
            }
        } else {
            tmp.outputStream().use { o -> input.copyTo(o) }
            copied++
        }
        entries.put(path, PakEntry(path, tmp))?.file?.delete()
    }
}
