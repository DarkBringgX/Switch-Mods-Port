package com.silverka.mhrport.core

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Tekstur tidak bisa/tidak perlu dikonversi; file asli disalin apa adanya. */
class TexSkip(message: String) : Exception(message)

/**
 * Pengganti Asterisk_MHR_Tex_Chopper_PC.exe + Asterisk_MHR_Tex_Chopper_Switch.exe.
 * Membaca .tex.28 versi PC (tanpa swizzle) lalu menulis .tex.28 versi Switch
 * (block-linear swizzle, per-mip, nol di ujung dibuang) tanpa lewat file DDS.
 */
object TexConverter {
    private const val PACKET = 16

    private class Fmt(val mtx: Int, val mty: Int, val texW: Int, val texH: Int)

    private fun ceilDiv(a: Int, b: Int) = (a + b - 1) / b

    private fun ulog2(x: Int): Int = if (x <= 1) 0 else 32 - Integer.numberOfLeadingZeros(x - 1)

    private fun bcBytes(dxgi: Int): Int = when (dxgi) {
        70, 71, 72, 79, 80, 81 -> 8                 // BC1, BC4
        73, 74, 75, 76, 77, 78, 82, 83, 84,
        94, 95, 96, 97, 98, 99 -> 16                // BC2, BC3, BC5, BC6H, BC7
        else -> 0
    }

    private fun bitsPerPixel(dxgi: Int): Int = when (dxgi) {
        in 1..4 -> 128
        in 9..14, in 15..18 -> 64
        in 23..32, in 33..38, in 39..47, 67, 87, 88, 89, in 90..93 -> 32
        in 48..59 -> 16
        in 60..65 -> 8
        85, 86, 115 -> 16
        else -> 0
    }

    private fun formatOf(dxgi: Int): Fmt {
        val bpb = bcBytes(dxgi)
        if (bpb != 0) return Fmt(4, 4, 4 * (PACKET / bpb), 4)
        val bits = bitsPerPixel(dxgi)
        if (bits == 0) throw TexSkip("format DXGI $dxgi belum didukung")
        val bytes = (bits + 7) / 8
        if (PACKET % bytes != 0) throw TexSkip("format DXGI $dxgi (piksel $bytes byte) belum didukung")
        val xp = PACKET / bytes
        return Fmt(xp, 1, xp, 1)
    }

    /** (swizzle lebar, swizzle tinggi) = getSwizzleSizes pada tool asli. */
    private fun swizzleSizes(w: Int, h: Int, tw: Int, th: Int): IntArray {
        val dx = ulog2(ceilDiv(w, tw))
        val dy = ulog2(ceilDiv(h, th))
        return intArrayOf(maxOf(0, minOf(4, dx - 3)), maxOf(0, minOf(4, dy - 3)))
    }

    private fun mapOffset(x: Int, y: Int, wcount: Int, sw: Int, sh: Int): Int {
        val suW = 4 shl sw
        val suH = 8 shl sh
        val suArea = suW * suH
        val hyperWCount = ceilDiv(wcount, suW)
        val sbx = x / suW
        val sby = y / suH
        val ix = x % suW
        val iy = y % suH
        val blkX = ix / 4
        val blkY = iy / 8
        val bx = ix % 4
        val by = iy % 8
        val sqx = bx / 2
        val sqy = by / 2
        val lx = bx % 2
        val ly = by % 2
        return sby * suArea * hyperWCount + sbx * suArea +
            blkX * 32 * (1 shl sh) + blkY * 32 +
            sqx * 16 + sqy * 4 + lx * 2 + ly
    }

    private fun swizzleMip(data: ByteArray, w: Int, h: Int, tw: Int, th: Int, sh: Int): ByteArray {
        val wcount = ceilDiv(w, tw)
        val hcount = ceilDiv(h, th)
        val suW = 4
        val suH = 8 shl sh
        val hyperW = ceilDiv(wcount, suW) * suW
        val hyperH = ceilDiv(hcount, suH) * suH
        val out = ByteArray(hyperW * hyperH * PACKET)
        val npk = minOf(ceilDiv(data.size, PACKET), wcount * hcount)
        for (i in 0 until npk) {
            val x = i % wcount
            val y = i / wcount
            val o = mapOffset(x, y, wcount, 0, sh) * PACKET
            val s = i * PACKET
            val len = minOf(PACKET, data.size - s)
            System.arraycopy(data, s, out, o, len)
        }
        return out
    }

    private fun trimZeros(d: ByteArray): ByteArray {
        var n = d.size
        while (n > 0 && d[n - 1].toInt() == 0) n--
        return if (n == d.size) d else d.copyOf(n)
    }

    /** Ambil data satu mip dari file PC, buang padding baris bila ada. */
    private fun readMip(src: ByteArray, off: Long, pitch: Int, size: Int, xcount: Int, ycount: Int, bpb: Int): ByteArray {
        val expected = xcount * ycount * bpb
        val rowBytes = xcount * bpb
        if (off < 0 || off + size > src.size) throw TexSkip("offset mip di luar file")
        val o = off.toInt()
        if (pitch > rowBytes && size >= pitch * ycount) {
            val out = ByteArray(expected)
            for (r in 0 until ycount) System.arraycopy(src, o + r * pitch, out, r * rowBytes, rowBytes)
            return out
        }
        val out = ByteArray(expected)
        System.arraycopy(src, o, out, 0, minOf(expected, size))
        return out
    }

    fun convert(src: ByteArray): ByteArray {
        if (src.size < 40) throw TexSkip("file terlalu kecil")
        if (src[0] != 'T'.code.toByte() || src[1] != 'E'.code.toByte() || src[2] != 'X'.code.toByte())
            throw TexSkip("bukan file TEX")
        val bb = ByteBuffer.wrap(src).order(ByteOrder.LITTLE_ENDIAN)
        val version = bb.getInt(4)
        if (version != 28) throw TexSkip("versi tex $version tidak diproses")
        val width = bb.getShort(8).toInt() and 0xFFFF
        val height = bb.getShort(10).toInt() and 0xFFFF
        val counts = bb.getShort(14).toInt() and 0xFFFF
        val imageCount = counts and 1023
        val mipCount = counts shr 12
        val format = bb.getInt(16)
        val swizzleControl = bb.getInt(20)
        val cubemap = bb.getInt(24)
        if (swizzleControl == 1) throw TexSkip("sudah format Switch")
        if (imageCount < 1 || mipCount < 1) throw TexSkip("jumlah gambar/mip tidak valid")
        if (src.size < 40 + 16 * imageCount * mipCount) throw TexSkip("header mip terpotong")

        val f = formatOf(format)
        val mpacket = ceilDiv(PACKET, ceilDiv(f.texW, f.mtx) * ceilDiv(f.texH, f.mty))

        val headers = ByteBuffer.allocate(16 * imageCount * mipCount).order(ByteOrder.LITTLE_ENDIAN)
        val body = ByteArrayOutputStream()
        val base0 = 40L + 16L * imageCount * mipCount
        var base = base0
        for (img in 0 until imageCount) {
            for (mip in 0 until mipCount) {
                val p = 40 + 16 * (img * mipCount + mip)
                val off = bb.getLong(p)
                val pitch = bb.getInt(p + 8)
                val size = bb.getInt(p + 12)
                val mw = ceilDiv(width, 1 shl mip).coerceAtLeast(1)
                val mh = ceilDiv(height, 1 shl mip).coerceAtLeast(1)
                val xcount = ceilDiv(mw, f.mtx)
                val ycount = ceilDiv(mh, f.mty)
                val raw = readMip(src, off, pitch, size, xcount, ycount, mpacket)
                val sy = swizzleSizes(mw, mh, f.texW, f.texH)[1]
                val swz = swizzleMip(raw, mw, mh, f.texW, f.texH, sy)
                val trimmed = trimZeros(swz)
                headers.putLong(base)
                headers.putInt(trimmed.size)   // compressedSize
                headers.putInt(swz.size)       // uncompressedSize
                body.write(trimmed)
                base += trimmed.size
            }
        }

        val sy0 = swizzleSizes(width, height, f.texW, f.texH)[1]
        val out = ByteBuffer.allocate(40 + headers.capacity() + body.size()).order(ByteOrder.LITTLE_ENDIAN)
        out.put('T'.code.toByte()).put('E'.code.toByte()).put('X'.code.toByte()).put(0.toByte())
        out.putInt(28)
        out.putShort(width.toShort())
        out.putShort(height.toShort())
        out.putShort(1)                                        // depth
        out.putShort(((mipCount shl 12) or imageCount).toShort())
        out.putInt(format)
        out.putInt(1)                                          // swizzleControl
        out.putInt(if (cubemap != 0) 4 else 0)
        out.put(0.toByte()).put(0.toByte())                    // unkn04
        out.putShort(0)                                        // NULL0
        out.put(sy0.toByte())                                  // swizzleHeightDepth
        out.put(0.toByte())                                    // swizzleWidth
        out.putShort(0)                                        // NULL1
        out.putShort(7)                                        // SEVEN
        out.putShort(1)                                        // ONE_1
        out.put(headers.array())
        out.put(body.toByteArray())
        return out.array()
    }
}
