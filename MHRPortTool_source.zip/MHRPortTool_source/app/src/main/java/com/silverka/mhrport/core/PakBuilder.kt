package com.silverka.mhrport.core

import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** File yang akan masuk PAK: [path] relatif seperti "natives/NSW/...", isi ada di [file]. */
class PakEntry(val path: String, val file: File)

/**
 * Penulis PAK patch RE Engine v4 (KPKA), tanpa kompresi.
 * Layout: header 16 byte, TOC (48 byte/entri), lalu data.
 */
object PakBuilder {
    fun write(entries: List<PakEntry>, out: OutputStream, onProgress: (Int, Int) -> Unit = { _, _ -> }) {
        val n = entries.size
        val header = ByteBuffer.allocate(16).order(ByteOrder.LITTLE_ENDIAN)
        header.put('K'.code.toByte()).put('P'.code.toByte()).put('K'.code.toByte()).put('A'.code.toByte())
        header.put(4.toByte()).put(0.toByte())      // versi mayor 4, minor 0
        header.putShort(0)                          // feature flag
        header.putInt(n)                            // jumlah file
        header.putInt(0)                            // fingerprint
        out.write(header.array())

        var offset = 16L + 48L * n
        val toc = ByteBuffer.allocate(48 * n).order(ByteOrder.LITTLE_ENDIAN)
        for (e in entries) {
            val size = e.file.length()
            toc.putInt(Murmur3.pathHash(e.path.lowercase()))
            toc.putInt(Murmur3.pathHash(e.path.uppercase()))
            toc.putLong(offset)
            toc.putLong(size)   // compressed
            toc.putLong(size)   // uncompressed
            toc.putLong(0L)     // atribut: tanpa kompresi
            toc.putLong(0L)     // checksum
            offset += size
        }
        out.write(toc.array())

        val buf = ByteArray(1 shl 16)
        for ((i, e) in entries.withIndex()) {
            BufferedInputStream(FileInputStream(e.file)).use { input ->
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    out.write(buf, 0, r)
                }
            }
            onProgress(i + 1, n)
        }
        out.flush()
    }
}
