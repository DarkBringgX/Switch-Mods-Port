package com.silverka.mhrport.core

/** MurmurHash3 x86 32-bit (sama dengan MurMur3.dll yang dipakai RisePakPatch). */
object Murmur3 {
    fun hash32(data: ByteArray, seed: Int): Int {
        val c1 = 0xcc9e2d51L.toInt()
        val c2 = 0x1b873593
        var h1 = seed
        val nblocks = data.size / 4
        for (i in 0 until nblocks) {
            val p = i * 4
            var k1 = (data[p].toInt() and 0xff) or
                ((data[p + 1].toInt() and 0xff) shl 8) or
                ((data[p + 2].toInt() and 0xff) shl 16) or
                ((data[p + 3].toInt() and 0xff) shl 24)
            k1 *= c1
            k1 = Integer.rotateLeft(k1, 15)
            k1 *= c2
            h1 = h1 xor k1
            h1 = Integer.rotateLeft(h1, 13)
            h1 = h1 * 5 + 0xe6546b64L.toInt()
        }
        val tail = nblocks * 4
        var k = 0
        val rem = data.size and 3
        if (rem >= 3) k = k xor ((data[tail + 2].toInt() and 0xff) shl 16)
        if (rem >= 2) k = k xor ((data[tail + 1].toInt() and 0xff) shl 8)
        if (rem >= 1) {
            k = k xor (data[tail].toInt() and 0xff)
            k *= c1
            k = Integer.rotateLeft(k, 15)
            k *= c2
            h1 = h1 xor k
        }
        h1 = h1 xor data.size
        h1 = h1 xor (h1 ushr 16)
        h1 *= 0x85ebca6bL.toInt()
        h1 = h1 xor (h1 ushr 13)
        h1 *= 0xc2b2ae35L.toInt()
        h1 = h1 xor (h1 ushr 16)
        return h1
    }

    /** Hash nama file RE Engine: UTF-16LE, seed 0xFFFFFFFF. */
    fun pathHash(path: String): Int =
        hash32(path.toByteArray(Charsets.UTF_16LE), -1)
}
