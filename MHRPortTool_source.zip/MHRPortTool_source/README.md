# MHR Port Tool (Android)

Aplikasi Android native (Kotlin) pengganti `Tools_port.zip` + Winlator:
mengubah mod Monster Hunter Rise **PC** menjadi **PAK patch untuk Switch**
(`re_chunk_000.pak.patch_0XX.pak`). Tidak perlu Winlator lagi.

## Cara pakai
1. Download mod dari Nexus (ZIP) — atau ekstrak sendiri sampai ada folder `natives`.
2. Buka app → **Pilih file ZIP mod** (atau pilih folder yang berisi `natives`).
3. **Pilih folder output**.
4. Isi nomor patch (mulai 016, naik otomatis tiap sukses) → **Konversi & buat PAK**.
5. Salin PAK hasilnya ke folder game, sebelah `re_chunk_000.pak`.

Yang dikerjakan app (sama dengan `auto_port.bat`):
`natives/STM` → `natives/NSW`, semua `*.tex.28` dikonversi PC→Switch
(swizzle block-linear), lalu semua file dibungkus jadi PAK v4.

## Cara mendapatkan APK (tanpa PC)
1. Buat repo GitHub baru, upload seluruh isi folder ini (termasuk `.github`).
2. Tab **Actions** → *Build APK* → tunggu hijau → unduh artifact `MHRPortTool-debug-apk`.
3. Ekstrak ZIP artifact, install `app-debug.apk`.

Atau dengan PC: buka folder ini di Android Studio → *Build > Build APK*.

## Isi proyek
- `core/TexConverter.kt` — Tex Chopper PC + Switch (tanpa perantara DDS)
- `core/PakBuilder.kt`, `core/Murmur3.kt` — RisePakPatch (KPKA v4, hash MurmurHash3 UTF-16LE seed 0xFFFFFFFF)
- `core/Porter.kt`, `core/Sources.kt` — alur auto_port (ZIP / folder)
- `reference/` — referensi Python + tes untuk algoritma swizzle & konversi

## Status
Sudah diuji: algoritma swizzle (cocok dengan nilai uji bawaan tool asli dan dengan
block-linear Switch standar), struktur header .tex hasil konversi, vektor uji Murmur3.
**Belum diuji:** kompilasi Kotlin dan hasil di game sungguhan (lingkungan pembuatan tidak
punya Android SDK/Gradle dan tidak ada file mod contoh).

## Perbedaan/batasan dibanding tool asli
- Tekstur `streaming` dan `.tex` yang sudah format Switch disalin apa adanya.
- Format piksel tak umum (mis. 96-bit) disalin apa adanya, dicatat di log.
- Mip kecil pada BC1/BC4 yang tidak penuh satu paket 16 byte kini di-pad nol
  (tool asli membuangnya jadi kosong).
- Urutan entri PAK diurutkan abjad.

Kredit alat asli: AsteriskAmpersand (Tex Chopper), MHVuze (RisePakPatch), Silver KA (auto_port).
