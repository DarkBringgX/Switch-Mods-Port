import random, struct
from port_ref import *
random.seed(7)
def make_pc_tex(w, h, nmip, fmt, bpb_block, mtx=4, mty=4):
    nimg = 1; data = b''; hdrs = b''; base = 40 + 16 * nmip; raws = []
    for m in range(nmip):
        mw, mh = max(1, ceil_div(w, 1 << m)), max(1, ceil_div(h, 1 << m))
        n = ceil_div(mw, mtx) * ceil_div(mh, mty) * bpb_block
        raw = bytes(random.randrange(256) for _ in range(n)); raws.append(raw)
        hdrs += struct.pack('<QII', base + len(data), ceil_div(mw, mtx) * bpb_block, n); data += raw
    head = struct.pack('<4sIHHHHIiIBBH', b'TEX\0', 28, w, h, 1, (nmip << 12) | nimg, fmt, -1, 0, 0, 0, 0) + b'\0' * 8
    return head + hdrs + data, raws
for (w, h, nmip, fmt, bpb, mt) in [(256, 256, 9, 98, 16, (4, 4)), (512, 256, 10, 71, 8, (4, 4)), (128, 128, 8, 28, 16, (4, 1)), (1024, 1024, 11, 83, 16, (4, 4))]:
    src, raws = make_pc_tex(w, h, nmip, fmt, bpb, *mt)
    out = convert(src)
    # parse hasil
    magic, ver, W, H, d, counts, f, swc, cube, *_ = struct.unpack('<4sIHHHHIiIBBH', out[:32])
    assert (swc, ver, f) == (1, 28, fmt)
    nm = counts >> 12
    sd = struct.unpack('<BBHHH', out[32:40]); assert sd[3:] == (7, 1)
    mtx, mty, tw, th = fmt_of(fmt)
    for m in range(nm):
        off, cs, us = struct.unpack_from('<QII', out, 40 + 16 * m)
        mw, mh = max(1, ceil_div(w, 1 << m)), max(1, ceil_div(h, 1 << m))
        blob = out[off:off + cs] + b'\0' * (us - cs)
        sy = swizzle_sizes(mw, mh, tw, th)[1]
        wc, hc = ceil_div(mw, tw), ceil_div(mh, th)
        flat = b''
        for i in range(wc * hc):
            o = map_offset(i % wc, i // wc, wc, 0, sy) * 16
            flat += blob[o:o + 16]
        assert flat[:len(raws[m])] == raws[m] + b'\0' * 0 or flat.startswith(raws[m]), (w, h, m)
    print(w, h, 'fmt', fmt, 'ok, size', len(src), '->', len(out))
print('KONVERSI OK')
