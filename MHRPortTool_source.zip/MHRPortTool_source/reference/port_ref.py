"""Referensi Python untuk logika MHR PC->Switch (hasil bongkar Tex Chopper + RisePakPatch).
Dipakai untuk menguji algoritma sebelum ditulis ulang ke Kotlin."""
import struct

def ceil_div(a, b): return (a + b - 1) // b
def ulog2(x): return 0 if x <= 1 else (x - 1).bit_length()

def swizzle_sizes(w, h, tw, th):
    dx = ulog2(ceil_div(w, tw)); dy = ulog2(ceil_div(h, th))
    return max(0, min(4, dx - 3)), max(0, min(4, dy - 3))

def map_offset(x, y, wcount, sw, sh):
    su_w = 4 * (1 << sw); su_h = 8 * (1 << sh)
    su_area = su_w * su_h
    hyper_w_count = ceil_div(wcount, su_w)
    sbx, sby = x // su_w, y // su_h
    ix, iy = x % su_w, y % su_h
    blk_x, blk_y = ix // 4, iy // 8
    bx, by = ix % 4, iy % 8
    sqx, sqy = bx // 2, by // 2
    lx, ly = bx % 2, by % 2
    return (sby * su_area * hyper_w_count + sbx * su_area
            + blk_x * 32 * (1 << sh) + blk_y * 32
            + sqx * 16 + sqy * 4 + lx * 2 + ly)

def swizzle_mip(data, w, h, tw, th, sh, sw=0):
    wcount, hcount = ceil_div(w, tw), ceil_div(h, th)
    su_w = 4 * (1 << sw); su_h = 8 * (1 << sh)
    hyper_w = ceil_div(wcount, su_w) * su_w
    hyper_h = ceil_div(hcount, su_h) * su_h
    out = bytearray(hyper_w * hyper_h * 16)
    npk = min(ceil_div(len(data), 16), wcount * hcount)
    padded = data + b"\0" * (npk * 16 - len(data))
    for i in range(npk):
        x, y = i % wcount, i // wcount
        o = map_offset(x, y, wcount, sw, sh) * 16
        out[o:o + 16] = padded[i * 16:(i + 1) * 16]
    return bytes(out)


def fmt_of(dxgi):
    bc8 = {70, 71, 72, 79, 80, 81}
    bc16 = {73, 74, 75, 76, 77, 78, 82, 83, 84, 94, 95, 96, 97, 98, 99}
    if dxgi in bc8 or dxgi in bc16:
        bpb = 8 if dxgi in bc8 else 16
        return 4, 4, 4 * (16 // bpb), 4
    if dxgi in (27, 28, 29, 30, 31, 32, 87, 91):
        return 4, 1, 4, 1
    raise ValueError(dxgi)


def convert(src):
    magic, ver, w, h, depth, counts, fmt, swc, cube, u0, u1, n0 = struct.unpack('<4sIHHHHIiIBBH', src[:32])
    assert magic == b'TEX\0' and ver == 28 and swc != 1
    nimg, nmip = counts & 1023, counts >> 12
    mtx, mty, tw, th = fmt_of(fmt)
    mpk = ceil_div(16, ceil_div(tw, mtx) * ceil_div(th, mty))
    hdr = b''; body = b''; base = 40 + 16 * nimg * nmip
    for img in range(nimg):
        for mip in range(nmip):
            off, pitch, size = struct.unpack_from('<QII', src, 40 + 16 * (img * nmip + mip))
            mw, mh = max(1, ceil_div(w, 1 << mip)), max(1, ceil_div(h, 1 << mip))
            xc, yc = ceil_div(mw, mtx), ceil_div(mh, mty)
            raw = src[off:off + xc * yc * mpk]
            sy = swizzle_sizes(mw, mh, tw, th)[1]
            swz = swizzle_mip(raw, mw, mh, tw, th, sy)
            trimmed = swz.rstrip(b'\0')
            hdr += struct.pack('<QII', base, len(trimmed), len(swz))
            body += trimmed; base += len(trimmed)
    sy0 = swizzle_sizes(w, h, tw, th)[1]
    head = struct.pack('<4sIHHHHIiIBBH', b'TEX\0', 28, w, h, 1, (nmip << 12) | nimg, fmt, 1, 4 if cube else 0, 0, 0, 0)
    head += struct.pack('<BBHHH', sy0, 0, 0, 7, 1)
    return head + hdr + body
