import random
from port_ref import *
# 1) nilai uji bawaan tool asli: CoordinateMapping((16,16),(1,1),(1,1)).mapToOffset(13,11) == 231
assert map_offset(13, 11, 16, 1, 1) == 231
# 2) bandingkan dengan algoritma block-linear Tegra X1 standar
def tegra_addr(x, y, width_bytes, bh):
    gobs_w = ceil_div(width_bytes, 64)
    xb = x * 16
    gob = (y // (8 * bh)) * 512 * bh * gobs_w + (xb // 64) * 512 * bh + ((y % (8 * bh)) // 8) * 512
    xm, ym = xb % 64, y % 8
    return gob + ((xm % 64) // 32) * 256 + ((ym % 8) // 2) * 64 + ((xm % 32) // 16) * 32 + (ym % 2) * 16 + (xm % 16)
random.seed(1)
for _ in range(2000):
    wc = random.randint(1, 70); hc = random.randint(1, 200); sh = random.randint(0, 4)
    x = random.randrange(wc); y = random.randrange(hc)
    assert map_offset(x, y, wc, 0, sh) * 16 == tegra_addr(x, y, ceil_div(wc, 4) * 64, 1 << sh), (wc, hc, sh, x, y)
# 3) swizzle -> deswizzle bolak-balik
def deswz(buf, w, h, tw, th, sh):
    wc, hc = ceil_div(w, tw), ceil_div(h, th)
    out = bytearray()
    for i in range(wc * hc):
        o = map_offset(i % wc, i // wc, wc, 0, sh) * 16
        out += buf[o:o + 16]
    return bytes(out)
for (w, h, tw, th) in [(256, 256, 4, 4), (1024, 512, 8, 4), (64, 64, 4, 4), (512, 512, 4, 1), (4096, 2048, 4, 4)]:
    n = ceil_div(w, tw) * ceil_div(h, th) * 16
    d = bytes(random.randrange(1, 256) for _ in range(min(n, 200000))) * (n // min(n, 200000) + 1)
    d = d[:n]
    sw, sh = swizzle_sizes(w, h, tw, th)
    s = swizzle_mip(d, w, h, tw, th, sh)
    assert deswz(s, w, h, tw, th, sh) == d
    print(w, h, 'sy=', sh, 'ok')
print('SEMUA TES LULUS')
